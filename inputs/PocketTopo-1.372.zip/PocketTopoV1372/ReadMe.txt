English:


Installation

Currently there is no installer available.

To install the application, copy the unzipped �PocketTopo� directory to the
�Program Files� directory on the PDA. For easy access, a shortcut to the exe
file can be copied to the start menu (�Windows\Start Menu�).

If execution fails, the .Net Compact Framework 2.0 may be missing (on older
devices). It can be loaded from:
http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=9655156b-356b-4a2c-857c-e62f50ae9a55

Additionally, the program may be run directly on a Windows PC. Simply double
click the exe file to start it. The window layout looks a bit strange on the
PC because it is made for a PDA.
If there is no .Net Framework installed on the PC, it can be loaded from:
http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=0856eacb-4362-4b0d-8edd-aab15c5e04f5



Deutsch:


Installation

Es gibt im Moment keinen Installer.

Zum Installieren muss das entpackte �PocketTopo� Verzeichnis ins Verzeichnis 
"Programme" (oder "Program Files") kopiert werden. Zum einfacheren Starten
kann eine Verkn�pfung des Exe Files ins Startmen� eingef�gt werden
("Windows\Startmen�" oder "Windows\Start Menu").

Wenn beim Starten eine Fehlermeldung erscheint, fehlt das .Net Compact
Framework 2.0 (m�glich bei �lteren Ger�ten). Dieses kann geladen werden von:
http://www.microsoft.com/downloads/details.aspx?familyid=9655156b-356b-4a2c-857c-e62f50ae9a55&displaylang=de

Das Programm l�uft auch direkt auf einem Windows PC. Dazu einfach das Exe File
doppelklicken. Da es f�r den PDA geschrieben ist, sieht es auf dem PC etwas
gew�hnungsbed�rftig aus.

Falls noch kein .Net Framework auf dem PC installiert ist, kann es von hier
geladen werden:
http://www.microsoft.com/downloads/details.aspx?familyid=0856EACB-4362-4B0D-8EDD-AAB15C5E04F5&displaylang=de




Version History:

1.0
first version

1.1
Renumber command corrected

1.2
XSections in Toporobot import corrected
Reference altitude in Toporobot export corrected
Improved compatibility in DXF export
New Features:
Therion export (Export menu)
Support for XSection sketches (Sketch view context menus)
Feet option (Option menu)
"Continue Here" in data context menu
Statistics (cave length & depth) in map view
Station info (id & coordinates) for tapped stations

1.21
Backsight shots in Therion export corrected

1.22
Sign of declination correction in Toporobot export corrected

1.23
Simple station numbers in text export corrected

1.34
3D export
Thick lines (mainly for VGA screens)
Toporobot export with merge into existing Toporobot file
Up/down angle limit in Toporobot export
Station info cycles trough all alias stations
Sketch move mode to correct sketch offset problems (use key '9')
VisualTopo export & import 
More options for DXF export
Improved window layout on PC
Bug Correction in side view projection
Support for forward and backward shots
Read command in calibration menu
Optional station IDs in map and Sketch view
Optional station IDs in DXF export
Selected measurement highlighted in sketch view
No return needed for data entry.
Missing cross sections corrected

1.35
Correction in calibration calculation to avoid coefficient overflow.
Option to include all survey data in graphics export.
Orange color in drawings.
Display of length and depth of actual data in Map view.
Screenshot function in Map and Sketch views.
Improved VisualTopo import.
Improved scaling on VGA screen.

1.36
Simple loop closure added.
"Connect Here" command in data context menu.
New scales down to 1:10 (for Archeologists).
Screen redraw optimization for large screens.

1.37
Corrected Therion export.
Improved side view projection.
Option to include grid in graphics export.
Renumber corrected for forward & backward shots.
Slovenian translation.

1.371
Corrected Therion export for forward & backward shots.
Distances >100m for DistoX2

1.372
Support for nonlinearity corrections.
Commands for remote Laser control.


Known Issues:

The sketches may be moved away from the survey shots in some cases due to an error correction in V1.3.
They key '9' mode in the drawing view may be used to readjust the location of the sketches.

There may be problems with side view representation and with Toporobot export
if you close loops by connecting the end of a series to an already defined station.
Workaround: Do not close loops in PocketTopo.
